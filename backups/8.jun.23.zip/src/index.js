import React from 'react';
import ReactDOM from 'react-dom';
import L0D from './L0D-main';
import 'bootstrap/dist/css/bootstrap.min.css';

ReactDOM.render(<React.StrictMode>
    <L0D />
    </React.StrictMode>,
  document.getElementById('root-l0d')
);
